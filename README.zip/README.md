### task1.sql – High-Value Customers with Multiple Products

*Scenario*:  
The business wants to identify high-value customers who have both a savings and an investment plan – a key cross-selling opportunity.

*Objective*:  
Write a query to find customers who have *at least one funded savings plan* and *one funded investment plan*, sorted by total deposits.

*Expected Output Columns*:
- owner_id
- name
- savings_count
- investment_count
- total_deposits

*Relevant Tables*:
- users_customuser
- savings_savingsaccount
- plans_plan

---

### task2.sql – Transaction Frequency Analysis

*Scenario*:  
The finance team wants to analyze how frequently customers transact to help segment users into behavioral groups such as frequent or occasional users.

*Objective*:  
Calculate the average number of transactions per customer per month and classify each customer into the following frequency categories:
- *High Frequency*: ≥ 10 transactions/month  
- *Medium Frequency*: 3–9 transactions/month  
- *Low Frequency*: ≤ 2 transactions/month

*Expected Output Columns*:
- frequency_category
- customer_count
- avg_transactions_per_month

*Relevant Tables*:
- users_customuser
- savings_savingsaccount

---

### task3.sql – Account Inactivity Alert

*Scenario*:  
The operations team wants to proactively flag accounts that may need attention due to inactivity.

*Objective*:  
Find all *active savings or investment accounts* that have had *no inflow transactions* in the past 365 days (1 year).

*Expected Output Columns*:
- plan_id
- owner_id
- type
- last_transaction_date
- inactivity_days

*Relevant Tables*:
- plans_plan
- savings_savingsaccount

---

### task4.sql – Customer Lifetime Value (CLV) Estimation

*Scenario*:  
The marketing team wants to estimate each customer's potential lifetime value based on a simplified profit model.

*Objective*:  
For each customer, assuming a profit per transaction of *0.1% of the transaction value*, calculate:
- Account tenure (in months, since signup)
- Total transactions
- Estimated CLV using the formula:  
  *CLV = (total_transactions / tenure_months) * 12 * avg_profit_per_transaction*

*Expected Output Columns*:
- customer_id
- name
- tenure_months
- total_transactions
- estimated_clv

*Relevant Tables*:
- users_customuser
- savings_savingsaccount

---

## Notes

- All queries were written and tested using [insert DBMS, e.g., PostgreSQL or MySQL].
- The assessment tasks were provided via the following link:

*Assessment Instructions Link*:  
[Click to View](https://drive.google.com/file/d/1hK2Ht5zw7m22sskJR2KCYiC1Kl6iZ48n/view?usp=sharing)

## Contact

If you have any questions or need further clarification, feel free to contact me.

Best regards,  
Constance Martins. 

