WITH txn_summary AS (
    SELECT 
        s.owner_id AS customer_id,
        COUNT(s.id) AS total_transactions,
        SUM(s.transaction_value) AS total_value
    FROM savings_savingsaccount s
    GROUP BY s.owner_id
),
tenure_calc AS (
    SELECT 
        id AS customer_id,
        name,
        DATEDIFF(CURRENT_DATE, signup_date)/30 AS tenure_months
    FROM users_customuser
),
clv_calc AS (
    SELECT 
        t.customer_id,
        u.name,
        u.tenure_months,
        t.total_transactions,
        ROUND((t.total_transactions / NULLIF(u.tenure_months, 0)) * 12 * (0.001 * t.total_value / NULLIF(t.total_transactions, 0)), 2) AS estimated_clv
    FROM txn_summary t
    JOIN tenure_calc u ON t.customer_id = u.customer_id
)
SELECT * 
FROM clv_calc
ORDER BY estimated_clv DESC;